set serveroutput on;

DECLARE
 -- Definicion de funciones y variables

BEGIN

  dbms_output.put_line('Hola Mundo');

  dbms_output.put_line('Hola Fernando');

END;
/